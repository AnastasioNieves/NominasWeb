-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.6.12-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla empresa.empleados: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` (`nombre`, `dni`, `sexo`, `categoria`, `anyos`) VALUES
	('Ada Lovelace', '32000031R', 'F', 1, 2),
	('James Cosling', '32000032G', 'M', 9, 7),
	('Anastasio Nieves', '32000033A', 'M', 3, 4);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;

-- Volcando datos para la tabla empresa.nominas: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `nominas` DISABLE KEYS */;
INSERT INTO `nominas` (`id`, `dni`, `salario`) VALUES
	(1, '32000032G', 245000),
	(3, '32000033A', 110000),
	(7, '32000031R', 245000);
/*!40000 ALTER TABLE `nominas` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
